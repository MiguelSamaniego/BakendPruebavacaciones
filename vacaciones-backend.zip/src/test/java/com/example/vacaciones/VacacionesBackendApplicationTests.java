package com.example.vacaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacacionesBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
